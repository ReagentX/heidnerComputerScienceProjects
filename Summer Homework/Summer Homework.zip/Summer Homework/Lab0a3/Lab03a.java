
/**
 * Write a description of class Lab03a here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lab03a{
public static void main(String args[]) {
        System.out.println(" Chris Sardegna \t 7-3-13 " ); 
        System.out.println(" This is a Dog" );
        System.out.println(" \n\n\n\n" );
        System.out.println("                            __ " );
        System.out.println("     ,                    ,\" e`--o " );
        System.out.println("    ((                   (  | __,' " ); 
        System.out.println("     \\\\~----------------' \\_;/ " );
        System.out.println("     (                      / " );
        System.out.println("     /) ._______________.  ) " );
        System.out.println("    (( (               (( ( " );
        System.out.println("     ``-\'               ``-\' " ); 
    } 
}
