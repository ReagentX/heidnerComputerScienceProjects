
/**
 * Write a description of class Lab0a2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lab0a2
{
      public static void main(String[] args)
      {
          System.out.println("Chris Sardegna \t 7-3-13 \n\n" ); 
          System.out.println("+++++++++++++++++++++++++ " );
          System.out.println("+++++++++++++++++++++++++ " );
          System.out.println("+++                   +++ " );
          System.out.println("+++                   +++ " );
          System.out.println("+++                   +++ " );
          System.out.println("+++    CompSci        +++ " );
          System.out.println("+++                   +++ " );
          System.out.println("+++                   +++ " );
          System.out.println("+++                   +++ " );
          System.out.println("+++                   +++ " );
          System.out.println("+++++++++++++++++++++++++ " );
          System.out.println("+++++++++++++++++++++++++ " );
        } 
}
