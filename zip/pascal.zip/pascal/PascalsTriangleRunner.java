// A+ Computer Science  -  www.apluscompsci.com
//Name - Chris Sardegna
//Date - 4/3/14
//Class - Period 5
//Lab  -

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import static java.lang.System.*;

public class PascalsTriangleRunner
{
	public static void main( String args[] ) throws IOException{
	    PascalsTriangle run = new PascalsTriangle(10);
	}
}



