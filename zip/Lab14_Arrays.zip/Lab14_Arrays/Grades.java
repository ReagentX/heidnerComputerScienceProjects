//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.lang.System;
import java.lang.Math;
import java.util.Scanner;

public class Grades
{
	//add a double[] array instance variable

	//constructors

	//make a private getSum() that returns a double

	//make a public getAverage() method that returns a double

	//toString method

}