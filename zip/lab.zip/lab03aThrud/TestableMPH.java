
/**
 * Write a description of interface TestableMPH here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface TestableMPH
{
     public void setNums(int dist, int hrs, int mins);

    public void calcMPH();

    public void print();
    
    public int getDistance();
    
    public int getHours() ;
    
    public int getMinutes() ;
    
    public double getMPH() ;
}
