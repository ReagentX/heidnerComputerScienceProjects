
/**
 * Write a description of interface TestableTriangle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface TestableTriangle
{
    public void setSides(int a, int b, int c);

    public void calcPerimeter( );

    public void calcArea( );

    public void print( );
    
    public int getSideA();
    
    public int getSideB();
    
    public int getSideC();
    
    public double getPerimeter();
    
    public double getTheArea();
}
