// A+ Computer Science  -  www.apluscompsci.com
//Name - Chris Sardegna
//Date - 4/23/13
//Class - Period 5
//Lab  -

import java.awt.Color;
import info.gridworld.grid.Grid;
import info.gridworld.world.World;
import info.gridworld.grid.Location;
import info.gridworld.grid.BoundedGrid;

public class AtCounterRunner
{
    public static void main(String[] args)
    {
        AtCounterWorld game = new AtCounterWorld();
        game.show();
    }
}