//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class ArrayStatsRunner
{
	public static void main(String args[])
	{
	}
}



