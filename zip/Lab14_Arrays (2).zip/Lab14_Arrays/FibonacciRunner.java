//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class FibonacciRunner
{
	public static void main(String args[])
	{
		//add test cases
	}
}