//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.util.Scanner;

public class Histogram
{
	//add and int[] array instance variable

	//constructor

	//set method

	//toString method
}